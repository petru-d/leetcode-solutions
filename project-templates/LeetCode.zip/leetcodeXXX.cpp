using namespace std;

namespace Solution
{
}

int main()
{
    return 0;
}

